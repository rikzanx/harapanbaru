
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image_category` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Gate Valve','img/gate-valve.jpg','2022-01-27 01:35:54','2022-01-30 19:01:30'),(2,'Globe Valve','img/globe-valve.jpg','2022-01-27 01:35:54','2022-01-27 01:35:54'),(3,'Ball Valve','img/ball-valve.webp','2022-01-27 01:35:54','2022-01-27 01:35:54');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `about` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `telp` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image_company` varchar(255) NOT NULL,
  `lat` double DEFAULT 0,
  `lng` double DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'UD Harapan Baru','Kami adalah perusahaan yang bergerak di bidang valve, fitting. Melayani pemesanan valve dan jasa service / reparasi, pemasangan, instalasi pipa hydrant.','Jl, Songoyudan I No.27D, Surabaya 60162','+6285101440330','udharapan.teknik@gmail.com','img/1660129144-1656921046-logo harapan baru.png',-7.2367248,112.7422357,'2022-01-27 01:35:53','2022-09-30 08:30:53');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deleted_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deleted_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_inv` int(11) DEFAULT NULL,
  `no_invoice` varchar(255) NOT NULL,
  `duedate` date DEFAULT NULL,
  `id_customer` varchar(255) DEFAULT NULL,
  `name_customer` varchar(255) DEFAULT NULL,
  `address_customer` varchar(255) DEFAULT NULL,
  `phone_customer` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `diskon_rate` int(11) NOT NULL DEFAULT 0,
  `tax_rate` int(11) NOT NULL DEFAULT 0,
  `profit` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deleted_invoices` WRITE;
/*!40000 ALTER TABLE `deleted_invoices` DISABLE KEYS */;
INSERT INTO `deleted_invoices` VALUES (2,2,'2022/INV/08/0002','2022-08-06',NULL,'tes','kjhkj','09',NULL,0,0,100000000,'2022-08-06 04:59:28','2022-08-06 04:59:28');
/*!40000 ALTER TABLE `deleted_invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deleted_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deleted_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_of` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `item_price` int(11) NOT NULL,
  `duedate` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deleted_items` WRITE;
/*!40000 ALTER TABLE `deleted_items` DISABLE KEYS */;
INSERT INTO `deleted_items` VALUES (2,2,'pcs','tes',1,125000000,'2022-08-06','2022-08-06 04:59:28','2022-08-06 04:59:28');
/*!40000 ALTER TABLE `deleted_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_product` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images_products` WRITE;
/*!40000 ALTER TABLE `images_products` DISABLE KEYS */;
INSERT INTO `images_products` VALUES (1,1,'img/product/gate-valve.jpg','2022-01-27 01:35:54','2022-01-27 01:35:54'),(2,2,'img/product/globe-valve.jpg','2022-01-27 01:35:54','2022-01-27 01:35:54'),(3,3,'img/product/ball-valve.webp','2022-01-27 01:35:54','2022-01-27 01:35:54'),(4,1,'img/product/gate-valve.jpg',NULL,NULL),(5,1,'img/product/gate-valve.jpg',NULL,NULL),(6,1,'img/product/gate-valve.jpg',NULL,NULL),(14,12,'img/product/1657053378-wafer-vulkanize-kelebek-vana-nikel-klapeli-pn16-1596794118-800.jpg','2022-07-05 13:36:18','2022-07-05 13:36:18');
/*!40000 ALTER TABLE `images_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images_sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images_sliders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image_slider` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images_sliders` WRITE;
/*!40000 ALTER TABLE `images_sliders` DISABLE KEYS */;
INSERT INTO `images_sliders` VALUES (1,'img/valve-cover-1.png','2022-01-27 01:35:53','2022-01-27 01:35:53'),(2,'img/valve-cover-2.png','2022-01-27 01:35:54','2022-01-27 01:35:54'),(3,'img/valve-cover-3.png','2022-01-27 01:35:54','2022-01-27 01:35:54');
/*!40000 ALTER TABLE `images_sliders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_inv` int(11) DEFAULT NULL,
  `no_invoice` varchar(255) NOT NULL,
  `duedate` date DEFAULT NULL,
  `id_customer` varchar(255) DEFAULT NULL,
  `name_customer` varchar(255) DEFAULT NULL,
  `address_customer` varchar(255) DEFAULT NULL,
  `phone_customer` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `diskon_rate` int(11) NOT NULL DEFAULT 0,
  `tax_rate` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `profit` int(11) NOT NULL DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tanggal_pengiriman` date DEFAULT NULL,
  `bayar` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (5,4,'2022/INV/07/0004','2022-07-04',NULL,'Heri','Pandaan','081334344944','- Pembayaran melalui rekening BCA 2130420632 a/n Muhammad Rikzan\r\n- Garansi 6 Bulan',0,0,'2022-07-04 04:22:05',200000,'2023-06-01 20:30:11','2022-09-30',0),(6,6,'2022/INV/07/0006','2022-07-04',NULL,'Pak Tono','Surabaya','081554083000','-',0,0,'2022-07-04 04:26:36',2500000,'2022-09-30 08:44:53','2022-09-30',0),(8,8,'2022/INV/07/0008','2022-07-04',NULL,'Greafin RIvaldy','Sidoarjo','08517411414','Pembayaran lunas',0,0,'2022-07-04 20:25:09',400000,'2022-09-30 08:44:53','2022-09-30',0),(10,9,'2022/INV/07/0009','2022-07-13',NULL,'Astri','Sidoarjo','08','lunas',0,0,'2022-07-13 14:27:58',300000,'2022-09-30 08:44:53','2022-09-30',0),(11,11,'2022/INV/07/0011','2022-07-13',NULL,'Riyadi / yongkin','Kalimati','08','kurang 800.000',0,0,'2022-07-13 14:30:00',1800000,'2022-10-01 00:40:37','2022-09-30',0),(12,12,'2022/INV/07/0012','2022-07-13',NULL,'Astri','Sidoarjo','08','dp 2jt kurang 2,6',0,0,'2022-07-13 14:31:10',550000,'2022-09-30 08:44:53','2022-09-30',0),(13,13,'2022/INV/07/0013','2022-07-13',NULL,'Pak zein','jakarta','08',NULL,0,0,'2022-07-13 14:33:08',4750000,'2022-09-30 08:44:53','2022-09-30',0),(14,14,'2022/INV/07/0014','2022-07-18',NULL,'PT Rukina Sukses Abadi','Surabaya','-',NULL,0,0,'2022-07-18 05:50:09',600000,'2022-09-30 08:44:53','2022-09-30',0),(15,15,'2022/INV/07/0015','2022-07-31',NULL,'Astri','Sidoarjo','0',NULL,0,0,'2022-07-31 01:44:21',250000,'2022-09-30 08:44:53','2022-09-30',0),(16,16,'2022/INV/07/0016','2022-07-31',NULL,'Astri','Sidoarjo','0',NULL,0,0,'2022-07-31 01:46:59',750000,'2022-09-30 08:44:53','2022-09-30',0),(25,1,'2022/INV/08/0001','2022-08-11',NULL,'Astri','Sidoarjo','0',NULL,0,0,'2022-08-11 07:42:56',250000,'2022-09-30 08:44:53','2022-09-30',0),(26,2,'2022/INV/08/0002','2022-08-13',NULL,'PT galangan kapal madura','-','-',NULL,0,0,'2022-08-12 22:27:22',200000,'2022-09-30 08:44:53','2022-09-30',0),(27,1,'2022/INV/09/0001','2022-09-16',NULL,'Pak Jimmi','Surabaya','-',NULL,0,0,'2022-09-15 20:01:25',2000000,'2022-09-30 08:44:53','2022-09-30',0),(28,2,'2022/INV/09/0002','2022-09-21',NULL,'Pak jimmi','surabaya','-',NULL,0,0,'2022-09-20 19:13:54',0,'2022-09-30 08:44:53','2022-09-30',0),(29,3,'2022/INV/09/0003','2022-09-21',NULL,'Pak jimmi','Surabaya','-',NULL,0,0,'2022-09-20 21:59:16',0,'2022-09-30 08:44:53','2022-09-30',0),(30,4,'2022/INV/09/0004','2022-09-26',NULL,'Pak Eko','Kupang','-',NULL,0,0,'2022-09-25 20:47:31',800000,'2022-09-30 08:44:53','2022-09-30',0),(31,5,'2022/INV/09/0005','2022-09-29',NULL,'CV Putra Jagat Mandiri','Pasuruan','-',NULL,0,0,'2022-09-28 19:11:00',0,'2022-09-30 08:37:56','2022-09-30',0),(32,1,'2022/INV/10/0001','2022-10-01',NULL,'pak junaidi','malang','-',NULL,0,0,'2022-10-01 03:33:14',0,'2022-10-01 03:33:48','2022-10-01',0),(33,2,'2022/INV/10/0002','2022-10-04',NULL,'PT GAPURA','-','-',NULL,0,0,'2022-10-03 21:04:53',400000,'2022-10-03 21:49:59','2022-10-04',0),(34,3,'2022/INV/10/0003','2022-10-13',NULL,'Astri','Sidoarjo','-',NULL,0,0,'2022-10-12 17:20:05',0,'2022-10-12 17:20:05',NULL,0),(35,4,'2022/INV/10/0004','2022-10-13',NULL,'PT Gapura','-','-',NULL,0,0,'2022-10-12 21:38:59',0,'2022-10-12 21:38:59',NULL,0),(36,5,'2022/INV/10/0005','2022-10-17',NULL,'Pak Jimmy','-','-',NULL,0,0,'2022-10-16 22:43:12',0,'2022-10-16 22:43:12',NULL,0),(37,1,'2022/INV/11/0001','2022-11-04',NULL,'Pak Jimmy','-','-',NULL,0,0,'2022-11-03 20:27:23',0,'2022-11-03 20:27:59','2022-11-04',0),(40,1,'2022/INV/12/0001','2022-12-01',NULL,'PT GAPURA','-','-',NULL,0,0,'2022-12-01 00:01:45',0,'2022-12-01 00:01:45',NULL,0),(41,2,'2022/INV/12/0002','2022-12-10',NULL,'Bu Astri','Jl. Merpati 1 Blok Q No 9, Pabean, Kec. Sedati, Sidoarjo','082140998400',NULL,0,0,'2022-12-10 08:48:07',0,'2023-03-28 03:31:21','2023-01-17',7000000),(42,3,'2022/INV/12/0003','2022-12-19',NULL,'CV Berkah Pratama Sejahtera','Citra Harmoni Blok E2 No.40','+6231-99788499','Garansi 1 Tahun',0,0,'2022-12-18 23:16:50',0,'2022-12-18 23:18:15','2022-12-19',0),(44,1,'2023/INV/01/0001','2023-01-27',NULL,'Bu Astri','Jl. Merpati 1 Blok Q No 9, Pabean, Kec. Sedati, Sidoarjo','082140998400',NULL,0,0,'2023-03-28 03:26:29',0,'2023-03-28 03:26:29',NULL,0),(45,2,'2023/INV/03/0002','2023-03-18',NULL,'Bu Astri','Jl. Merpati 1 Blok Q No 9, Pabean, Kec. Sedati, Sidoarjo','082140998400','dibayar 8.450.000 + 3.200.000',0,0,'2023-03-28 03:30:27',0,'2023-03-30 01:24:05','2023-03-30',11650000),(46,1,'2023/INV/05/0001','2023-05-25',NULL,'CV Berkah Pratama Sejahtera','Citra Harmoni Blok E2 No.40','031 99788499','Garansi 1 Tahun',0,0,'2023-05-25 02:08:06',0,'2023-05-25 15:45:55','2023-05-26',0),(47,1,'2023/INV/07/0001','2023-07-05',NULL,'CV Berkah Pratama Sejahtera','Citra Harmoni Blok E2 No.40.Melody Garden Trosobo Sidoarjo','+6231-99788499',NULL,0,0,'2023-07-04 17:55:04',0,'2023-07-04 20:49:22','2023-07-05',0),(48,2,'2023/INV/07/0002','2023-07-05',NULL,'CV Berkah Pratama Sejahtera','Citra Harmoni Blok E2 No.40.Melody Garden Trosobo Sidoarjo','+6231-99788499',NULL,0,0,'2023-07-04 17:57:13',0,'2023-07-04 20:47:54','2023-07-05',0);
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_of` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `item_price` int(11) NOT NULL,
  `duedate` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (31,6,'pcs','Gate Valve SS304 2 inch #150 RF',1,2500000,'2022-07-04','2022-07-04 04:26:36','2022-08-05 08:22:02'),(32,8,'pcs','Globe Valve 2 inch jis 5k cast iron',1,1200000,'2022-07-04','2022-07-04 20:25:09','2022-08-05 08:22:02'),(33,10,'pcs','PRV 21/2 inch 10k 317',1,3750000,'2022-07-13','2022-07-13 14:27:58','2022-08-05 08:22:02'),(36,12,'pcs','Globe v 4 inch 10k fcds kitz',1,4600000,'2022-07-13','2022-07-13 14:31:10','2022-08-05 08:22:02'),(37,13,'pcs','Check V ss304 3 inch 10k kitz',2,2750000,'2022-07-13','2022-07-13 14:33:08','2022-08-05 08:22:03'),(38,13,'pcs','Check V ss304 3 inch 10k kitz',1,2500000,'2022-07-13','2022-07-13 14:33:08','2022-08-05 08:22:03'),(39,13,'pcs','Strainer 4 inch ss304 kitz 10k',1,5500000,'2022-07-13','2022-07-13 14:33:08','2022-08-05 08:22:03'),(40,14,'pcs','Gate Valve 14\" jis 10k flange',1,15000000,'2022-07-18','2022-07-18 05:50:09','2022-08-05 08:22:03'),(41,15,'pcs','Pressure Reducing Valve 21/2 inch brand 317',1,4500000,'2022-07-31','2022-07-31 01:44:21','2022-08-05 08:22:03'),(42,16,'pcs','Globe Valve flange 10k kitz fcd-s 3 inch',2,3250000,'2022-07-31','2022-07-31 01:46:59','2022-08-05 08:22:03'),(43,16,'pcs','Globe Valve flange 10k kitz fcd-s 21/2 inch',1,2500000,'2022-07-31','2022-07-31 01:46:59','2022-08-05 08:22:03'),(54,26,'pcs','Gate Valve 11/4 inch 5k flange',1,1100000,'2022-08-13','2022-08-12 22:27:22','2022-08-12 22:27:22'),(55,25,'pcs','Check Kitz 1/2 inch drat',2,475000,'2022-08-11','2022-08-15 22:28:59','2022-08-15 22:28:59'),(56,27,'pcs','SWING CHECK VALVE KITZ CI 10K-100 4 INCH',8,3250000,'2022-09-16','2022-09-15 20:01:25','2022-09-15 20:01:25'),(57,28,'pcs','Gate Valve kitz 4 inch 10k',4,3200000,'2022-09-21','2022-09-20 19:13:54','2022-09-20 19:13:54'),(58,28,'pcs','check valve kitz 4 inch 10k',1,3250000,'2022-09-21','2022-09-20 19:13:55','2022-09-20 19:13:55'),(59,29,'pcs','Ball valve kitz 1/2 inch ss 600wog',3,300000,'2022-09-21','2022-09-20 21:59:16','2022-09-20 21:59:16'),(60,29,'pcs','Ball valve kitz 3/4 inch ss 600wog',2,390000,'2022-09-21','2022-09-20 21:59:17','2022-09-20 21:59:17'),(61,30,'pcs','Butterfly valve tomoe 14 inch cast iron steam ss304',1,7500000,'2022-09-26','2022-09-25 20:47:31','2022-09-25 20:47:31'),(66,31,'pcs','Ball valve kitz 3 inch JIS 10K cast iron',4,3200000,'2022-09-29','2022-09-30 08:37:56','2022-09-30 08:37:56'),(67,11,'pcs','Globe V 11/2 inch 10k SS304',1,1800000,'2022-07-13','2022-10-01 00:40:37','2022-10-01 00:40:37'),(71,32,'pcs','Flange galvanis 6\" 10k',5,312000,'2022-10-01','2022-10-01 03:35:49','2022-10-01 03:35:49'),(72,32,'pcs','Flange galvanis 10\" 10k',1,585000,'2022-10-01','2022-10-01 03:35:49','2022-10-01 03:35:49'),(74,33,'pcs','Gate valve 21/2 inch 5k',1,1600000,'2022-10-04','2022-10-03 21:49:59','2022-10-03 21:49:59'),(75,34,'pcs','Globe 2 inch FCDS Kitz',12,1900000,'2022-10-13','2022-10-12 17:20:05','2022-10-12 17:20:05'),(76,34,'pcs','Steamtrap 1 icnh drat',2,800000,'2022-10-13','2022-10-12 17:20:05','2022-10-12 17:20:05'),(77,34,'pcs','Globe 1 inch FCDS Kitz',10,800000,'2022-10-13','2022-10-12 17:20:05','2022-10-12 17:20:05'),(78,35,'pcs','Angle hydrant valve 40mm 5k',1,1200000,'2022-10-13','2022-10-12 21:38:59','2022-10-12 21:38:59'),(79,36,'pcs','Strainer 4\" KITZ CI 10K',2,3250000,'2022-10-17','2022-10-16 22:43:12','2022-10-16 22:43:12'),(80,36,'pcs','Swing Check 4\" KITZ CI ANSI125',2,3850000,'2022-10-17','2022-10-16 22:43:12','2022-10-16 22:43:12'),(81,36,'pcs','Butterfly Kitz 4\" Lever',2,750000,'2022-10-17','2022-10-16 22:43:12','2022-10-16 22:43:12'),(88,37,'pcs','Gate Valve 2\" bronze kitz',6,600000,'2022-11-04','2022-11-03 20:37:57','2022-11-03 20:37:57'),(91,40,'pcs','Strom Valve 4 inch jis 5k',1,4750000,'2022-12-01','2022-12-01 00:01:45','2022-12-01 00:01:45'),(98,42,'pcs','Globe Valve Steam 8 inch KITZ JIS 20K',1,13000000,'2022-12-19','2022-12-18 23:18:43','2022-12-18 23:18:43'),(108,44,'pcs','Globe Valve 1,5\" KSB BOA-H',3,750000,'2023-01-27','2023-03-28 03:26:29','2023-03-28 03:26:29'),(113,41,'pcs','Strainer 8 inch kitz CI 10k',1,8500000,'2022-12-10','2023-03-28 03:31:22','2023-03-28 03:31:22'),(114,41,'pcs','Swing check 6 inch yone',1,1750000,'2022-12-10','2023-03-28 03:31:22','2023-03-28 03:31:22'),(115,41,'pcs','Butterfly gearbox 6 inch kitz',1,1200000,'2022-12-10','2023-03-28 03:31:22','2023-03-28 03:31:22'),(116,41,'pcs','Butterfly gerabox 8 kitz',2,1800000,'2022-12-10','2023-03-28 03:31:22','2023-03-28 03:31:22'),(121,45,'pcs','Gate Valve 2\" 10K KITZ CI',2,1600000,'2023-03-18','2023-03-30 01:24:05','2023-03-30 01:24:05'),(122,45,'pcs','Gate Valve 2\" 10K KITZ CI',5,1750000,'2023-03-18','2023-03-30 01:24:05','2023-03-30 01:24:05'),(123,45,'pcs','Swing Check Valve 2\" 10K KITZ CI',2,1750000,'2023-03-18','2023-03-30 01:24:05','2023-03-30 01:24:05'),(124,45,'pcs','Strainer Valve 2\" 10K KITZ CI',1,1600000,'2023-03-18','2023-03-30 01:24:05','2023-03-30 01:24:05'),(133,46,'pcs','GLOBE VALVE STEAM DIA.2 INC FLANGE (PN40,DN50)',4,1000000,'2023-05-25','2023-05-25 15:45:55','2023-05-25 15:45:55'),(134,46,'pcs','GLOBE VALVE STEAM DIA.1 1/2 INC PN16',5,600000,'2023-05-25','2023-05-25 15:45:55','2023-05-25 15:45:55'),(136,5,'pcs','PRV 317 11/2 inch\r\nBrand : 317\r\nJIS 10K',1,3250000,'2022-07-04','2023-06-01 20:34:18','2023-06-01 20:34:18'),(139,48,'pcs','GLOBE VALVE STEAM DIA.3 INC PN16 CAST IRON',3,1200000,'2023-07-05','2023-07-04 20:47:54','2023-07-04 20:47:54'),(140,47,'pcs','CHECK VALVE SWING DIA 4 INC JIS 10K ALL SS',2,3800000,'2023-07-05','2023-07-04 20:49:22','2023-07-04 20:49:22');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_01_27_050836_create_companies_table',1),(6,'2022_01_27_050914_create_categories_table',1),(7,'2022_01_27_050928_create_products_table',1),(8,'2022_01_27_052044_create_images_products_table',1),(9,'2022_01_27_052820_create_images_sliders_table',1),(10,'2022_07_04_080331_create_invoices_table',2),(11,'2022_07_04_080426_create_items_table',2),(12,'2022_07_04_080456_create_invoice_items_table',2),(13,'2022_07_04_082343_drop_inovice_item_table',3),(14,'2022_08_06_114920_create_deleted_invoices_table',4),(15,'2022_08_06_114933_create_deleted_items_table',5),(16,'2022_08_06_151817_create_penawarans_table',6),(17,'2022_08_08_121300_create_wallets_table',7),(18,'2022_08_08_121331_create_transactions_table',8),(19,'2022_09_30_153214_add_tanggal_pengiriman_to_invoice_table',9),(20,'2023_03_28_095334_add_bayar_to_invoice_table',10),(23,'2023_06_02_034241_create_surat_penawarans_table',11),(24,'2023_06_02_034340_create_surat_penawaran_items_table',11);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `penawarans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `penawarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telp` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `penawarans` WRITE;
/*!40000 ALTER TABLE `penawarans` DISABLE KEYS */;
INSERT INTO `penawarans` VALUES (1,'erik','muhammadrikzan31@gmail.com','085101440330','Penawaran','Gate Valve','2022-08-06 15:27:21','2022-08-06 15:27:21'),(2,'tes','jbkjbjk@kjbjkb.djd','09809809','kjkjh','kjhjk','2022-08-06 08:36:53','2022-08-06 08:36:53'),(3,'jhj','8yjhkjH@khkjh.dhkbk','k080989','kbkjb','jkbjkb','2022-08-06 08:38:31','2022-08-06 08:38:31'),(4,'kjhjk','hhkkk@kjkh.kk','kjhkjh','kjhkj','hkjh','2022-08-06 08:39:32','2022-08-06 08:39:32'),(5,'kjbjkb','kjbjkb@jhj.cj','kjkj','kjhkjh','kjh','2022-08-06 08:44:37','2022-08-06 08:44:37'),(6,'tes','erik.kasbam@gmail.com','87878','hkhdk','jkdhjksd','2022-09-21 21:32:31','2022-09-21 21:32:31');
/*!40000 ALTER TABLE `penawarans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `material` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'Gate Valve','gate-valve','Cast Iron,Carbon Steel, Steinless Steel','2,3,4,5,6,8,10','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','Gate Valve','2022-01-27 01:35:54','2022-01-27 01:35:54'),(2,2,'Globe Valve','globe-valve','Cast Iron,Carbon Steel, Steinless Steel','2,3,4,5,6,8,10','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','Globe Valve','2022-01-27 01:35:54','2022-01-27 01:35:54'),(3,3,'Ball Valve','ball-valve','Cast Iron,Carbon Steel, Steinless Steel','2,3,4,5,6,8,10','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','Ball Valve','2022-01-27 01:35:54','2022-01-27 01:35:54'),(12,1,'Butterfly Valve','butterfly-valve','Cast Iron,Carbon Steel, Steinless Steel','2,3,4,5,6,8,10','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','Butterfly Valve','2022-01-30 18:59:26','2022-07-04 02:55:57');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `surat_penawaran_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surat_penawaran_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `suratpenawaran_id` int(11) NOT NULL,
  `item_of` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `item_price` int(11) NOT NULL,
  `duedate` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `surat_penawaran_items` WRITE;
/*!40000 ALTER TABLE `surat_penawaran_items` DISABLE KEYS */;
INSERT INTO `surat_penawaran_items` VALUES (3,4,'pcs','Globe Valve WCB KITZ \r\nSize: 4\"\r\nConn: Flange ANSI150',3,6000000,'2023-06-02','2023-06-01 21:34:35','2023-06-01 21:34:35');
/*!40000 ALTER TABLE `surat_penawaran_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `surat_penawarans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surat_penawarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_pnw` int(11) DEFAULT NULL,
  `no_surat` varchar(255) NOT NULL,
  `duedate` date DEFAULT NULL,
  `name_customer` varchar(255) DEFAULT NULL,
  `address_customer` varchar(255) DEFAULT NULL,
  `phone_customer` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `surat_penawarans` WRITE;
/*!40000 ALTER TABLE `surat_penawarans` DISABLE KEYS */;
INSERT INTO `surat_penawarans` VALUES (4,1,'2023/PNW/06/0001','2023-06-02','Bu Astri','Jl. Merpati 1 Blok Q No 9, Pabean, Kec. Sedati, Sidoarjo','082140998400','- Harga sudah include PPN\r\n- Garansi 6 Bulans','2023-06-01 21:07:47','2023-06-01 21:34:22');
/*!40000 ALTER TABLE `surat_penawarans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL DEFAULT 0,
  `tipe` varchar(255) NOT NULL,
  `balance_after` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1,2500000,'credit',2500000,'testing pemasukan','2022-08-08 06:20:08','2022-08-08 06:20:08'),(2,1,2500000,'debit',0,'testing pengeluaran','2022-08-08 06:20:08','2022-08-08 06:20:08'),(3,1,90000,'credit',90000,'testing','2022-08-08 07:02:20','2022-08-08 07:02:20'),(4,1,90000,'debit',0,'tes','2022-08-10 01:49:53','2022-08-10 01:49:53'),(5,1,20000,'credit',20000,'j','2022-10-01 00:07:54','2022-10-01 00:07:54');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@gmail.com',NULL,'$2y$10$p19sDNCRL/HuOtnvm6nkGOE8Xvk3FhUx0s4PHQN3HYHcmzDWTgWSG',NULL,'2022-01-27 01:35:53','2022-08-05 06:31:40');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wallets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `balance` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
INSERT INTO `wallets` VALUES (1,'perusahaan',20000,'Ini adalah uang perusahaan','2022-08-08 05:45:23','2022-10-01 00:07:54'),(3,'pribadi',0,'pribadi','2022-08-08 06:04:34','2022-08-08 06:04:34');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

